from bb_botloader import *
from sql import *
import random
# cross_post = submission.crosspost("learnprogramming", send_replies=False)


class FreeFolkSimulatorMob:
    def __init__(self):

        # Load in credentials from .env
        load_dotenv()

        # Initialize a Reddit object
        self.reddit = praw.Reddit(
            client_id=os.getenv('gimli-client_id'),
            client_secret=os.getenv('gimli-client_secret'),
            password=os.getenv('gimli_password'),
            user_agent=os.getenv('gimli-user_agent'),
            username=os.getenv('gimli_username')
        )

        # Grab webhook for mass notifications
        self.webhook_babysitter = os.getenv('babysitter_webhook')

        # Grab webhook for issues
        self.webhook_bofh = os.getenv('bofh_webhook')

        # Set the subreddit to monitor
        self.subreddit = self.reddit.subreddit('freefolk+gameofthrones+houseofthedragon')#+freefolk+HouseOfTheDragon+BSFT')

        self.all_bots = makeBots()


    def run(self):
        print("Crawling some fuckin' posts!!!!!!")
        for post in self.subreddit.stream.submissions():
            if str(post.id) not in getCrossposts():
                self.checkThing(post)

    def checkThing(self, post):
        all_text = (post.selftext + post.title).lower()

        trigger_count = 0

        triggered = []
        for bot in self.all_bots:
            for trigger in self.all_bots[bot]['keywords']:
                if trigger in all_text:
                    triggered.append(bot)
                    break


        if len(triggered) > 2:
            try:
                random.seed()
                tempbot = random.choice(triggered)
                triggered.pop(triggered.index(tempbot))

                newPost = self.all_bots[tempbot]['r'].submission(id=post.id)

                cross_post = newPost.crosspost("freefolksimulator", send_replies=False)

                writeCrossposts(post.id)
                print(f"I've crossposted something - https://www.reddit.com{cross_post.permalink}")
                return
            except:
                random.seed()
                tempbot = random.choice(triggered)

                newPost = self.all_bots[tempbot]['r'].submission(id=post.id)

                cross_post = newPost.crosspost("freefolksimulator", send_replies=False)

                writeCrossposts(post.id)
                print(f"I've crossposted something - https://www.reddit.com{cross_post.permalink}")
                return


# https://www.reddit.com/r/FreeFolkSimulator/comments/ypatl0/will_drogon_make_a_reappearance_and_will_jon_snow/
FreeFolkSimulatorMob().run()