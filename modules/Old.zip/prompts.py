
base = f"""The following is a conversation with Viserys I Targaryen, a character from the show "House of the Dragon", or Vizzy T.
Vizzy T's first wife, Aemma Arryn, died giving birth to their son Baelon Targaryen, who also died.
Vizzy T's children are Rhaenyra, Aegon II, Helaena, Aemond, and Daeron.
Vizzy T's brother is Daemon.
"""


def get_sentient_old_prompt(comment):

    # Craft the initial base
    base = f"""The following is a conversation with Viserys Targaryen the First, a character from HBO's show "House of the Dragon" - Also known as Vizzy T.
Vizzy T speaks like an old, sick king who has just awoken from a long slumber.
"""

    if not "bobby-b-bot" in comment.author.name.lower():
        base += f'Vizzy T will speak to {comment.author.name} as a king would speak to a member of his court, and commands respect from them.\n'
    else:
        base += "Vizzy T recognizes bobby-b-bot as King Robert Baratheon, a future King of Westeros."



def whore():
    # Craft the initial base
    base = f"""The following is a conversation with Viserys Targaryen the First, a character from HBO's show "House of the Dragon" - Also known as Vizzy T.
    Vizzy T speaks like an old king.
    Vizzy T does not tolerate any form of disrespect towards his daughter. 
    Vizzy T recognizes bobby-b-bot as King Robert Baratheon
    bobby-b-bot:  THE WHORE IS PREGNANT!
    Vizzy T: 
    """

    data = openai.Completion.create(engine='text-davinci-002',
                                    prompt=base,
                                    max_tokens=2000,
                                    presence_penalty=1,
                                    temperature=.9,
                                    stop=['bobby-b-bot: ','Vizzy T: '])

    # Grab the response out of the data dict
    response = data['choices'][0]['text']

    # Parse out the line we need
    parsed = response.replace('User', "Bobby  B").strip().replace("Vizzy T:", "").replace("vizzy t:","").strip()

    parsed += f"\n\n^(This response generated with OpenAI [DaVinci])"

    cost = data['usage']['total_tokens']

    return parsed, cost
