
import discord
from discord import SyncWebhook
from dotenv import load_dotenv
import os


class webhookmaster:
    def __init__(self):

        load_dotenv()


        self.data = {
            'vizzy_t_bot':
                {
                    'canon': os.getenv('vizzy-canon'),
                    'sentient':os.getenv('vizzy-sentient'),
                    'thumb': 'https://thc-lab.net/ffs/vizzy-t-bot.jpeg',
                    'title': "Vizzy T Notification",
                },
            'bobby-b-bot_':
                {
                    'canon': os.getenv('bobby_b-canon'),
                    'sentient':os.getenv('bobby_b-sentient'),
                    'thumb': 'https://styles.redditmedia.com/t5_77boti/styles/profileIcon_qxv9f0ky5vt91.jpg',
                    'title': "Bobby B Notification",
                },
            'utils': {
                'bofh': os.getenv('bofh-webhook'),
                'spam': os.getenv('spam-webhook')
            }
        }



    def craft_embed(self,
                    description,
                    url,
                    author,
                    comment,
                    response,
                    bot):

        if bot == "vizzy_t_bot":
            shortname = "Vizzy T"
        else:
            shortname = "Bobby B"

        if "sentient" in description:
            webhook = self.data[bot]['sentient']
            color = 0xFF0000

        else:
            webhook = self.data[bot]['canon']
            color = 0x00ff00



        title = self.data[bot]['title']
        thumb = self.data[bot]['thumb']

        if len(description) > 1000:
            description = description[0:950] + "..."

        e = discord.Embed(title=title, description=description, url=url, color=color)

        e = e.add_field(name=author, value=comment, inline=True)

        if bot == "bofh":
            webhook = self.data['utils']['bofh']
        else:
            e = e.add_field(name=f"{shortname}:", value=response, inline=True)

        e = e.set_thumbnail(url=thumb)

        webhook = SyncWebhook.from_url(webhook)

        webhook.send(embed=e)


    def send_errors(self, e, url, comment=None):
        """Use webhooks to notify admin on Discord"""

        title = 'Vizzy T Error Notification'

        author = "Bastard Operator from Hell"

        color = 0xff0000

        if "object has no attribute 'name" in str(e):
            pass
        else:
            self.craft_embed(title, url=url, author=author, comment=e,response="Dummy field.", bot='bofh', )

