from modules.cloud_sql import *
from modules.for_reddit import *

import discord
from discord import SyncWebhook
from dotenv import load_dotenv
import os


cloud_db = db(True)

def get_gen_len(gen, sub_to_check='freefolk'):
    """ Takes in an array of comments from a Redditor, and the subreddit to look through his history for

        Returns the amount of comments in the checked subreddit, and their total amount of comments
        """
    x = 0
    relevant = 0
    for thing in gen:
        if thing.subreddit.display_name == sub_to_check:
            relevant += 1

        x += 1

    # Return the relevant comment count, and the all comment count
    return relevant, x


def check_post(post, sub):
    """ Takes in a post object and a subreddit object"""

    # Get the title of the post
    query = post.title

    # Empty array to keep track of any potential reposts
    seen = []

    # Search through the provided subreddit for posts with the same title as the post we are checking
    for exPost in sub.search(query):

        # If the title is the same and the ID is not, it's probably a repost.
        if exPost.title == query and exPost.id != post.id:
            # Add it to the list
            seen.append(f'https://www.reddit.com{exPost.permalink}')

    # If there's a previous identical title, and this current post is not in our database yet, we should look further
    if seen and not cloud_db.check_db(post.id, 'spam'):

        # Get author details
        # Returns True, True unless they're probably a spam bot
        author_detail = check_user(post.author)

        # Hey, this looks like spam!
        if author_detail is not True:
            seen_posts = "\n".join(seen)
            footer = 'Please reach out to u/CarpathiaDev if this is an error.  If OP actually responds to this comment, they might be a real account.'
            response = author_detail + f"\n\nFound these similar posts:\n\n{seen_posts}\n\n{footer}"

            report = f"This is an exact repost, the title has been seen {len(seen)} times before and the account is new."

            return response, report
        else:
            return True, True
    else:
        return True, True


def check_user(author):
    """ Checks the author of a post, returns True if the author is trustworthy.  Returns a report if they are spammy."""
    # Data for the author's account

    # Account creation date / age
    created = author.created_utc
    now = datetime.now().timestamp()
    account_age = int(((now - created) / 60 / 60 / 24))
    if account_age > 365:
        return True

    # Data for the author's karma
    comment_karma = author.comment_karma
    post_karma = author.link_karma
    total_karma = comment_karma + post_karma
    if total_karma > 1500:
        return True

    # Data for the author's activity in the sub
    comment_count = author.comments.new(limit=None)
    comments_freefolk, comments_all = get_gen_len(comment_count)
    posts_count = author.submissions.new(limit=None)
    posts_freefolk, posts_all = get_gen_len(posts_count)
    freefolk_activity = comments_freefolk + posts_freefolk
    if freefolk_activity > 5:
        return True

    all_activity = comments_all + posts_all
    if all_activity > 15:
        return True

    else:
        response = f"""# This account is probably a repost bot.
|||
|:-|:-|
|Account Age|{account_age} days|
|Comments in r/FreeFolk|{comments_freefolk}|
|Posts in r/FreeFolk|{posts_freefolk}|
|Total Comment Karma|{comment_karma}|
|Total Post Karma|{post_karma}|
|Total Combined Instances of Activity|{all_activity}|
"""
        return response



def craft_embed(response, url):

        color = 0x00ff00

        title = "Spam Response"
        thumb = 'https://www.comodo.com/images/antispam-action.png'


        e = discord.Embed(title=title, description=response, url=url, color=color)

        e = e.set_thumbnail(url=thumb)

        webhook = SyncWebhook.from_url('https://discord.com/api/webhooks/1081384013949845526/2hIZD8P6Hf_0dtvyzE3bE4Sx-LdnZyCU3OZH5NWwsRj_dSfmRkJr4cuR7F_y9p3Q4EU_')

        webhook.send(embed=e)


def main():
    t = ["tyrion-client_id", "tyrion-client_secret", "tyrion-password", "tyrion-user_agent", "tyrion-username"]
    load_dotenv()

    bot = praw.Reddit(
        client_id=os.getenv(t[0]),
        client_secret=os.getenv(t[1]),
        password=os.getenv(t[2]),
        user_agent=os.getenv(t[3]),
        username=os.getenv(t[4])
    )

    sub = bot.subreddit("freefolk")

    # Set the subreddit stream to comments and posts
    for submission in sub.stream.submissions():#skip_existing=True):

        response, other = check_post(submission, sub)

        if response is True:
            pass
        else:
            submission.reply(body=response)
            cloud_db.write_obj(submission.id, 'spam')
            craft_embed(response, f'https://reddit.com{submission.permalink}')



main()