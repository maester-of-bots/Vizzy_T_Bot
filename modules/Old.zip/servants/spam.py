from modules.cloud_sql import *
from modules.for_reddit import *

import discord
from discord import SyncWebhook
from dotenv import load_dotenv
import os


cloud_db = db(True)

def get_gen_len(gen):
    x = 0
    ffp = 0
    for thing in gen:
        if thing.subreddit.display_name == 'freefolk':
            ffp += 1

        x += 1
    return ffp, x

def check_post(post, sub):
    query = post.title

    seen = []

    for exPost in sub.search(query):
        if exPost.title == query and exPost.id != post.id:
            seen.append(f'https://www.reddit.com{exPost.permalink}')

    if seen and not cloud_db.check_db(post.id, 'spam'):

        author_detail = check_user(post.author)

        if author_detail is not True:
            response = author_detail + "\n\nFound these similar posts:\n\n" + "\n".join(
                seen) + "\n\nPlease reach out to u/CarpathiaDev if this is an error.  If OP actually responds to this comment, they might be a real account."


            report = f"This is an exact repost, the title has been seen {len(seen)} times before and the account is new."

            return response, report
        else:
            return True, True
    else:
        return True, True


def check_user(author):

    # Data for the author's account

    created = author.created_utc

    now = datetime.now().timestamp()

    account_age = int(((now - created) / 60 / 60 / 24))

    if account_age > 365:

        return True

    # Data for the author's karma

    comment_karma = author.comment_karma

    post_karma = author.link_karma

    total_karma = comment_karma + post_karma

    if total_karma > 1500:

        return True

    # Data for the author's activity

    comment_count = author.comments.new(limit=None)

    comments_freefolk, comments_all = get_gen_len(comment_count)

    posts_count = author.submissions.new(limit=None)

    posts_freefolk, posts_all = get_gen_len(posts_count)

    freefolk_activity = comments_freefolk + posts_freefolk

    if freefolk_activity > 5:

        return True

    all_activity = comments_all + posts_all

    if all_activity > 15:

        return True

    else:

        response = f"""# This account is probably a repost bot.
|||
|:-|:-|
|Account Age|{account_age} days|
|Comments in r/FreeFolk|{comments_freefolk}|
|Posts in r/FreeFolk|{posts_freefolk}|
|Total Comment Karma|{comment_karma}|
|Total Post Karma|{post_karma}|
|Total Combined Instances of Activity|{all_activity}|
"""

        return response



def craft_embed(response, url):

        color = 0x00ff00

        title = "Spam Response"
        thumb = 'https://www.comodo.com/images/antispam-action.png'


        e = discord.Embed(title=title, description=response, url=url, color=color)

        e = e.set_thumbnail(url=thumb)

        webhook = SyncWebhook.from_url('https://discord.com/api/webhooks/1081384013949845526/2hIZD8P6Hf_0dtvyzE3bE4Sx-LdnZyCU3OZH5NWwsRj_dSfmRkJr4cuR7F_y9p3Q4EU_')

        webhook.send(embed=e)


def main():
    t = ["tyrion-client_id", "tyrion-client_secret", "tyrion-password", "tyrion-user_agent", "tyrion-username"]
    load_dotenv()

    bot = praw.Reddit(
        client_id=os.getenv(t[0]),
        client_secret=os.getenv(t[1]),
        password=os.getenv(t[2]),
        user_agent=os.getenv(t[3]),
        username=os.getenv(t[4])
    )

    sub = bot.subreddit("freefolk")

    # Set the subreddit stream to comments and posts
    for submission in sub.stream.submissions():#skip_existing=True):
        print(submission.title)

        response, other = check_post(submission, sub)

        if response is True:
            pass
        else:
            submission.reply(body=response)
            cloud_db.write_obj(submission.id, 'spam')
            craft_embed(response, f'https://reddit.com{submission.permalink}')



main()